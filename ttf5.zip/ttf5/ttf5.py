import pandas as pd
import matplotlib.pyplot as plt

print("Task 1")

data = pd.read_csv('company_sales_data.csv')

plt.figure(figsize=(10, 6))
plt.plot(data['month_number'], data['total_profit'],  color='red')

plt.xlabel('Month Number')
plt.ylabel('Total Profit')
plt.title('Company Profit per Month')
plt.ylim(100000, 500000)

plt.show()


print("Task 2 ")
plt.figure(figsize=(10, 6))
plt.plot(
    data['month_number'],data['total_profit'],
    linestyle=':',          
    color='red',             
    marker='o',             
    markerfacecolor='red',  
    linewidth=3,             
    label='Total Profit'     
)

plt.xlabel('Month Number')
plt.ylabel('Sold Units Number')
plt.title('Company Profit per Month')
plt.legend(loc='lower right')

plt.show()

print("Task 3")
plt.figure(figsize=(10, 6))

plt.plot(data['month_number'], data['facecream'], marker='o', label='Face Cream Sales Data')
plt.plot(data['month_number'], data['facewash'], marker='o', label='Face Wash Sales Data')
plt.plot(data['month_number'], data['toothpaste'], marker='o', label='Toothpaste Sales Data')
plt.plot(data['month_number'], data['bathingsoap'], marker='o', label='Toothpaste Sales Data')
plt.plot(data['month_number'], data['shampoo'], marker='o', label='Toothpaste Sales Data')
plt.plot(data['month_number'], data['moisturizer'], marker='o', label='Toothpaste Sales Data')

plt.xlabel('Month Number')
plt.ylabel('Units Sold')
plt.title('Monthly Sales Data for Each Product')
plt.legend(loc='upper left')
plt.grid(True)

plt.show()

print("Task 4")


plt.figure(figsize=(10, 6))
plt.scatter(data['month_number'], data['toothpaste'], color='purple', label='Toothpaste Sales')

plt.xlabel('Month Number')
plt.ylabel('Units Sold')
plt.title('Toothpaste Sales Data per Month')
plt.grid(True, linestyle='--')  
plt.legend(loc='upper left')

plt.show()

print("Task 5 ")

plt.figure(figsize=(10, 6))
bar_width = 0.35 
months = data['month_number']

plt.bar(months - bar_width/2, data['facecream'], width=bar_width, color='blue', label='Face Cream sales data')
plt.bar(months + bar_width/2, data['facewash'], width=bar_width, color='orange', label='Face Wash sales data')

plt.xlabel('Month Number')
plt.ylabel('Sales units in number')
plt.title('Facewash and Face Cream Sales Data')
plt.xticks(months) 
plt.legend()
plt.grid(True, which='both', linestyle='--', linewidth=0.5)

plt.show()

print("Task 6 ")

plt.figure(figsize=(10, 6))
plt.bar(data['month_number'], data['bathingsoap'], color='blue')
plt.xlabel('Month Number')
plt.ylabel('Sales units in number')
plt.title('Bathing Soap Sales Data per Month')
plt.grid(axis='y', linestyle='--', linewidth=0.7)
plt.savefig('bathing_soap_sales_data.png')  


plt.show()

print("Task 7 ")

plt.figure(figsize=(10, 6))
plt.hist(data['total_profit'], bins=6, color='blue', edgecolor='black', label='Profit data')

plt.xlabel('Profit range in dollar')
plt.ylabel('Actual Profit in dollar')
plt.title('Profit data')
plt.legend()


plt.show()

print("Task 8 ")
total_sales = {
    'Face Cream': data['facecream'].sum(),
    'Face Wash': data['facewash'].sum(),
    'Toothpaste': data['toothpaste'].sum(),
    'Bathing Soap': data['bathingsoap'].sum(),
    'Shampoo': data['shampoo'].sum(),
    'Moisturizer': data['moisturizer'].sum()
}

plt.figure(figsize=(10, 6))
plt.pie(total_sales.values(), labels=total_sales.keys(), autopct='%1.1f%%', startangle=140)
plt.title('Total Sales Distribution for Each Product ')

plt.show()

print("Task 9 ")


plt.figure(figsize=(12, 5))

plt.subplot(1, 2, 1)
plt.plot(data['month_number'], data['bathingsoap'], color='blue', marker='o')
plt.title('Bathing Soap Sales Data')
plt.xlabel('Month Number')
plt.ylabel('Units Sold')

plt.subplot(1, 2, 2)
plt.plot(data['month_number'], data['facewash'], color='orange', marker='o')
plt.title('Face Wash Sales Data')
plt.xlabel('Month Number')
plt.ylabel('Units Sold')

plt.tight_layout()  
plt.show()

print("Task 10 ")
months = data['month_number']
products = ['facecream', 'facewash', 'toothpaste', 'bathingsoap', 'shampoo', 'moisturizer']

plt.figure(figsize=(10, 6))
plt.stackplot(months, data[products].T, labels=products, colors=['orange', 'blue', 'green', 'red', 'purple', 'brown'])

plt.title('All Products Sales Data')
plt.xlabel('Month Number')
plt.ylabel('Units Sold')
plt.legend(loc='upper left')

plt.show()